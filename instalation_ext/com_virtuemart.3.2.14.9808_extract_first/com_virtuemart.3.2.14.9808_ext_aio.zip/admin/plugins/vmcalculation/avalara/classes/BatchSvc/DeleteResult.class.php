<?php
/**
 * DeleteResult.class.php
 */

/**
 * 
 *
 * @author    Avalara
 * @copyright � 2004 - 2011 Avalara, Inc.  All rights reserved.
 * @package   Batch
 */
class DeleteResult extends BaseResult {

}

?>
