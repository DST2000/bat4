<?php
/**
 * BatchSave.class.php
 */

/**
 * 
 *
 * @author    Avalara
 * @copyright � 2004 - 2011 Avalara, Inc.  All rights reserved.
 * @package   Batch
 */
class BatchSave {
  private $Batch; // Batch

  public function setBatch($value){$this->Batch=$value;} // Batch
  public function getBatch(){return $this->Batch;} // Batch

}

?>
